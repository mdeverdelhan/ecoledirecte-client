
package eu.verdelhan.ecoledirecte.v3.eleves.coordonneesfamille;

import java.util.List;
import eu.verdelhan.ecoledirecte.EcoleDirecteApiResponse;
import lombok.Getter;

@Getter
public class GetCoordonneesFamilleResponse extends EcoleDirecteApiResponse<List<CoordonneesFamille>> {

}
