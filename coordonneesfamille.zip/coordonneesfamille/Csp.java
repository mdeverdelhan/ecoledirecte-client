
package eu.verdelhan.ecoledirecte.v3.eleves.coordonneesfamille;

import com.google.gson.annotations.Expose;
import lombok.Getter;

@Getter
public class Csp {

    @Expose
    private String code;
    @Expose
    private String libelle;
}
